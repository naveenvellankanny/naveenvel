import { Component, OnInit } from '@angular/core';
import { GameserviceService } from '../gameservice.service';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  yourBalance:number=600;
  isPrice:boolean=false;
  constructor(private service:GameserviceService) { }
  ngOnInit() {
    this.service.getproducts();
  }
  get(b){
    if(b.GameRupees<=this.yourBalance){
      this.yourBalance=this.yourBalance -b.GameRupees;
    this.isPrice=false;
    }
    else
    {
    this.isPrice=true;
    }
}

}
