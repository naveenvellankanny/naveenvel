import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import{Iproduct} from './play/Iproduct';
@Injectable({
  providedIn: 'root'
})
export class GameserviceService {
  url:string="assets/GameList.json";

  productList: Iproduct[];
  constructor(private http:HttpClient) { 
    
  }
  
  getproducts():any{
    this.http.get<Iproduct[]>(this.url).subscribe(res=>{
      console.log(res);
      this.productList=res;
    })
}
}