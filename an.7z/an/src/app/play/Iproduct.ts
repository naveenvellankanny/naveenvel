export interface Iproduct{
    GameName:string;
    GameRupees:number;  
}
