import { Component, OnInit } from '@angular/core';
import { Iproduct } from './Iproduct';
import { GameserviceService } from '../gameservice.service';
@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  products:Iproduct[];
  isPrice:boolean=false;
  AvailableBalance:number=600;
  constructor(private service:GameserviceService) { }

  ngOnInit() {

    this.service.getproducts();
  
  }
  buy(b){
    if(b.GameRupees<=this.AvailableBalance){
      this.AvailableBalance=this.AvailableBalance -b.GameRupees;
    this.isPrice=false;
    }
    else
    {
    this.isPrice=true;
    }
}
}